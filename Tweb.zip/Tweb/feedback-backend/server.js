const express = require('express');
const cors = require('cors');
const feedbackRoutes = require('./routes/feedbackRoutes');
const activityRoutes = require('./routes/activityRoutes');

const app = express();
app.use(cors());
app.use(express.json());

// Add this middleware function
app.use((req, res, next) => {
    console.log(`${req.method} ${req.path}`);
    console.log('Body:', req.body);
    next();
});

app.use('/feedback', feedbackRoutes);
app.use('/activity', activityRoutes);

app.listen(3001, () => {console.log('Server listening on port 3001')});