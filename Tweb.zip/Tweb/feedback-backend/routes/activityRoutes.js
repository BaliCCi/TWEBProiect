const express = require('express');
const router = express.Router();
let activities = [];

router.post('/', (req, res) => {
    activities.push({ ...req.body, participants: [] });
    res.status(201).send();
});

router.get('/', (req, res) => {
    res.send(activities);
});

router.post('/join', (req, res) => {
    const { code, student } = req.body;
    const activity = activities.find(activity => activity.accessCode === code);
    if (!activity) {
        return res.status(400).send('Invalid code');
    }
    const activityEndTime = new Date(activity.date);
    activityEndTime.setMinutes(activityEndTime.getMinutes() + activity.duration);
    if (new Date() > activityEndTime) {
        return res.status(400).send('Activity has ended');
    }
    activity.participants.push(student);
    res.status(200).send();
});
module.exports = router;