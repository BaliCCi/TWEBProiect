const express = require('express');
const router = express.Router();
let feedbacks = [];

router.post('/', (req, res) => {
    feedbacks.push(req.body);
    res.status(201).send();
});

router.get('/', (req, res) => {
    res.send(feedbacks);
});

module.exports = router;