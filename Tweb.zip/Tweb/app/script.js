document.getElementById('join-form').addEventListener('submit', function(event) {
    event.preventDefault();
    var studentName = document.getElementById('student-name').value;
    var activityCode = document.getElementById('activity-code').value;

    console.log({ student: studentName, code: activityCode });

    fetch('http://localhost:3001/activity/join', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ student: studentName, code: activityCode }),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => console.log(data))
    .catch(error => console.error('Error:', error));
});

document.getElementById('create-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const description = document.getElementById('description').value;
    const date = document.getElementById('date').value;
    const accessCode = document.getElementById('access-code').value;
    const duration = document.getElementById('duration').value;
    fetch('http://localhost:3001/activity', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ description, date, accessCode, duration }),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => console.log(data))
    .catch(error => console.error('Error:', error));
});

document.querySelectorAll('.emoticons button').forEach(function(button) {
    button.addEventListener('click', function() {
        const emoticon = this.dataset.emoticon;
        fetch('http://localhost:3001/feedback', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ emoticon }),
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => console.log(data))
        .catch(error => console.error('Error:', error));
    });
});

fetch('http://localhost:3001/activity')
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(activities => {
        const activitiesDiv = document.getElementById('activities');
        activities.forEach(activity => {
            const activityDiv = document.createElement('div');
            activityDiv.className = 'activity';
            activityDiv.innerHTML = `
                <p>Description: ${activity.description}</p>
                <p>Date: ${activity.date}</p>
                <p>Access Code: ${activity.accessCode}</p>
                <p>Duration: ${activity.duration}</p>
            `;
            activitiesDiv.appendChild(activityDiv);
        });
    })
    .catch(error => console.error('Error:', error));