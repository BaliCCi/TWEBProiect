import React from 'react';

function FeedbackList({ feedbacks }) {
    return (
        <div>
            {feedbacks.map((feedback, index) => (
                <p key={index}>{feedback.feedback}</p>
            ))}
        </div>
    );
}

export default FeedbackList;