import React from 'react';

function ActivityList({ activities }) {
    return (
        <div>
            {activities.map((activity, index) => (
                <div key={index}>
                    <p>{activity.description}</p>
                    <p>{activity.date}</p>
                    <p>{activity.accessCode}</p>
                    <p>{activity.duration}</p>
                </div>
            ))}
        </div>
    );
}

export default ActivityList;