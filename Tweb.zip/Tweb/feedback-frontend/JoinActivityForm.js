import React, { useState } from 'react';
import axios from 'axios';

function JoinActivityForm() {
    const [code, setCode] = useState('');
    const [student, setStudent] = useState('');

    const handleSubmit = event => {
        event.preventDefault();
        axios.post('http://localhost:3001/activity/join', { code, student })
            .then(response => {
                if (response.data.success) {
                    setCode('');
                    setStudent('');
                    alert('Successfully joined the activity!');
                } else {
                    alert('Failed to join the activity: ' + response.data.message);
                }
            })
            .catch(error => {
                console.error(error);
                alert('An error occurred: ' + error.message);
            });
    };

    return (
        <form onSubmit={handleSubmit}>
            <input value={student} onChange={e => setStudent(e.target.value)} placeholder="Student Name" />
            <input value={code} onChange={e => setCode(e.target.value)} placeholder="Activity Code" />
            <button type="submit">Join Activity</button>
        </form>
    );
}

export default JoinActivityForm;