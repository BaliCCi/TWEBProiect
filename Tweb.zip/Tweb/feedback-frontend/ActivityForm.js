import React, { useState } from 'react';
import axios from 'axios';

function ActivityForm({ setActivities }) {
    const [description, setDescription] = useState('');
    const [date, setDate] = useState('');
    const [accessCode, setAccessCode] = useState('');
    const [duration, setDuration] = useState('');

    const handleSubmit = event => {
        event.preventDefault();
        axios.post('http://localhost:3001/activity', { description, date, accessCode, duration })
            .then(() => {
                setDescription('');
                setDate('');
                setAccessCode('');
                setDuration('');
                axios.get('http://localhost:3001/activity')
                    .then(response => setActivities(response.data));
            });
    };

    return (
        <form onSubmit={handleSubmit}>
            <input value={description} onChange={e => setDescription(e.target.value)} placeholder="Description" />
            <input value={date} onChange={e => setDate(e.target.value)} placeholder="Date" />
            <input value={accessCode} onChange={e => setAccessCode(e.target.value)} placeholder="Access Code" />
            <input value={duration} onChange={e => setDuration(e.target.value)} placeholder="Duration" />
            <button type="submit">Submit</button>
        </form>
    );
}

export default ActivityForm;