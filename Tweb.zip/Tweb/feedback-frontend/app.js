import React, { useState, useEffect } from 'react';
import axios from 'axios';
import FeedbackForm from './FeedbackForm';
import FeedbackList from './FeedbackList';
import ActivityForm from './ActivityForm';
import ActivityList from './ActivityList';
import JoinActivityForm from './JoinActivityForm';

function App() {
    const [feedbacks, setFeedbacks] = useState([]);
    const [activities, setActivities] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:3001/feedback')
            .then(response => setFeedbacks(response.data));
        axios.get('http://localhost:3001/activity')
            .then(response => setActivities(response.data));
    }, []);

    return (
        <div>
            <JoinActivityForm />
            <ActivityForm setActivities={setActivities} />
            <ActivityList activities={activities} />
            <FeedbackForm setFeedbacks={setFeedbacks} />
            <FeedbackList feedbacks={feedbacks} />
        </div>
    );
}

export default App;