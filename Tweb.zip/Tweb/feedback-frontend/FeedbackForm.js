import React, { useState } from 'react';
import axios from 'axios';

function FeedbackForm({ setFeedbacks }) {
    const [emoticon, setEmoticon] = useState('');

    const handleSubmit = emoticon => {
        axios.post('http://localhost:3001/feedback', { emoticon })
            .then(() => {
                setEmoticon('');
                axios.get('http://localhost:3001/feedback')
                    .then(response => setFeedbacks(response.data));
            });
    };

    return (
        <div>
            <button onClick={() => handleSubmit('smiley')}>😊</button>
            <button onClick={() => handleSubmit('frowny')}>☹️</button>
            <button onClick={() => handleSubmit('surprised')}>😮</button>
            <button onClick={() => handleSubmit('confused')}>😕</button>
        </div>
    );
}

export default FeedbackForm;